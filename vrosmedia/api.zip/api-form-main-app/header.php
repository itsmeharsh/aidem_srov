<?php
if($_SERVER['SERVER_NAME']=="localhost")
$path = "http://localhost/test/finalBS/index.php/ws/v1/";

else
$path = "http://vrosmedia.com/vrosmedia/index.php/ws/v1/";

?>





