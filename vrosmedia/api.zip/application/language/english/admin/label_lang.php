<?php

/*** PAGE ***/
$lang['LOGIN'] = "Login";
$lang['DASHBOARD'] = "Dashboard";
$lang['USER'] = "User";
$lang['DISTRIBUTOR'] = "Distributor";
$lang['ADMIN'] = "Admin ";
$lang['PROFILE'] = "Profile ";

/*COMMON*/
$lang['STATUS'] = "Status";
$lang['ACTION'] = "Action";
$lang['ADD'] = "Added";
$lang['EDIT'] = "Edited";
$lang['PLC_ENTER'] = "Enter";
$lang['SUBMIT_BTN'] = "Submit";
$lang['RESET_BTN'] = "Reset";
$lang['LIST'] = "List";

/*USER*/
$lang['FNM'] = "Firstname";
$lang['LNM'] = "Lastname";
$lang['UNM'] = "Username";
$lang['NM'] = "Name";
$lang['MNM'] = "Middlename";
$lang['PHONE'] = "Phone Number";
$lang['WORK_EMAIL'] = "Work Email";
$lang['WORK_PHONE'] = "Work Phone";
$lang['ADDRESS'] = "Address";
$lang['IMAGE'] = "Image";

$lang['EMAIL'] = "Email";

$lang['PLC_EMAIL'] = "Email";
$lang['PLC_PASSWORD'] = "Password";
$lang['PASSWORD'] = "Password";
$lang['REMEMBER'] = "Remember";
$lang['BTN_LOGIN'] = "Login";
$lang['STATE'] = "State";
$lang['NEW_PASSWORD'] = "New Password";
$lang['CONFIRM_PASSWORD'] = "Confirm Password";
$lang['CURRENT_PASSWORD'] = "Current Password";
$lang['ACCOUNT_TYPE'] = "Account Type";
$lang['BALANCE'] = "Balance";
$lang['MODE'] = "Mode";
$lang['COUNTRY'] = "Country";
$lang['CITY'] = "City";

$lang['DEPOSITE'] = "Deposit";
$lang['LOGIN'] = "Login";
$lang['AMOUNT'] = "Amount";
$lang['ACCEPT'] = "Accept";
$lang['CLOSE'] = "Close";
$lang['CREATED'] = "Created";
$lang['LAST_LOGGEDINN'] = "Last Login";
$lang['AMOUNT_ADDED'] = "Amount Added!";
$lang['AMOUNT_ERROR'] = "Invalid Amount!";




$lang['USER_MNG'] = "User Managments";
$lang['TEXT_NUMBER'] = "Texi Number";



$lang['BUSINESS_MNG'] = "Business Managments";
$lang['BNAME'] = "Business";
$lang['COVER_IMAGE'] = "Cover";
$lang['SINCE'] = "Since";
$lang['LOCATION'] = "Location";
$lang['TOTALLIKE'] = "Likes";
$lang['TOTALSHARE'] = "Share";
$lang['TOTALFAV'] = "Favorite";
$lang['AVG_RAT'] = "Rating";
$lang['PROFILE_PIC'] = "Profile Pic";


$lang['CAT'] = "Category";
$lang['CAT_MNG'] = "Category Managments";
$lang['CAT_TYPE'] = "Category Type";



// PLACE HOLDER
