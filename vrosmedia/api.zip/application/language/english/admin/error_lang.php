<?php
/*** LOGIN PAGE ***/
$lang['LOGIN_ERROR'] = "Email or password is incorrect.";
$lang['ERROR'] = "Problem in ";
$lang['EXITS'] = " Already exist.";

$lang['BLANK_VALUE'] = " All fileds are mendatory.";

$lang['ERRRO_BALANCE'] = " Insufficient Balance.";

$lang['LIMITEXITS'] = " Bounceback limit is reached.";
$lang['LimitWinningBalance'] = " Insufficient User Balance.";
$lang['INVALIDAMOUNT'] = " Amount must not equals 0.";

$lang['BLOCK'] = " You are block for ";

$lang['MINUTES'] = " Minutes.";


$lang['ATTEMPTS'] = "You have attempts ";
$lang['ATTEMPTS_REMAINING'] = " remaining";

$lang['SOMETHINGS_WENT_WRONG'] = "Somethings went wrong ,Please try again later.";







