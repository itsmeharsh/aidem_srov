<?php
/*** LOGIN PAGE ***/
$lang['LOGIN_SUCESS'] = "Login successfully.";
$lang['SUCCESS'] = " successfully ";

$lang['ADDED'] = "added successfully ";
$lang['EDITED'] = "edited successfully ";
//$lang['SUCCESS'] = " successfully ";
