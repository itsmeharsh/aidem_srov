<?php
$lang['REUQEST_SENT_SUCCESSFULLY'] = "Request sent Successfully.";
$lang['SOMETHINGS_WENT_WRONG'] = "Somethings Went wrong !Please try again later.";
$lang['REUQEST_ALREADY_SENT'] = "Reuqest Already sent.";
$lang['INVALID_REQUEST'] = "Invalid Request.";

$lang['REQUEST_ACCEPTED'] = "Accepted.";
$lang['REJECTED'] = "Rejected.";
$lang['SUCCESSFULLY'] = "Successfully.";
$lang['NO_DATA_FOUND'] = "No Data Found";


//notification
$lang['sent_Request'] = "sent_req";
$lang['accept_Request'] = "act_req";



$lang['sent_Request_title'] = "new friend request";
$lang['Accept_Request_title'] = "request accepted";
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

