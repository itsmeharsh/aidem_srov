<?php
$lang['EVENT_LIKE_SUCCESS'] = "Thank you for Liked Event!";
$lang['EVENT_DISLIKE_SUCCESS'] = "You Disliked Successfully.";

$lang['EVENT_SHARE_SUCCESS'] = "Thank you for sharing!.";
$lang['EVENT_REMOVESHARE_SUCCESS'] = "Shared Removed.";

$lang['EVENT_FAVORITE_SUCCESS'] = "Event Mark as your Favorite.";
$lang['EVENT_UNFAVORITE_SUCCESS'] = "Your Favorite removed sucessfully.";

$lang['COMMENT_POSTED_SUCCES'] = "Comment posted sucessfully.";

$lang['SUCESSFULLY_ADDED_ATTENDEE'] = "Attendee Added Successfully.";
$lang['ATTENDEE_ALREADY_EXITS'] = "Attendee already added.";


$lang['SUCCESSFULLY_SHARE_EVENT'] = "Event Share Successfully!";


//notification type

$lang['share_event_with_friends_type']="evt_share";


//notification title

$lang['share_event_with_friends_title'] = "you invited to check event!";


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
