
<!--<footer class="page-footer" >
   
    <div class="footer-copyright">
      <div class="container">
        <span>Copyright © 2016 <a class="grey-text text-lighten-4" href="#" target="_blank">VROS Media</a> All rights reserved.</span>
        <span class="right"> Design and Developed by <a class="grey-text text-lighten-4" href="#">VROS Media</a></span>
        </div>
    </div>
  </footer>-->