  <div class="container">
         

          <!--toasts-->
          <div id="toasts" class="section">
            <h4 class="header">Cateory Managements</h4>
            <div class="row">
              <div class="col s12 m4 l3">
                <p>You can select options from right side ,where you can manage whole category of VROS media Systems.</p>
              </div>
              <div class="col s12 m8 l9">
                <div class="row">
                  <a href="<?php echo ADMIN_MAIN_URL; ?>category/Adminlists/1" class="btn tooltipped col s4 l2 " data-position="bottom" data-delay="50" data-tooltip="Business">Business</a>
                  <a href="<?php echo ADMIN_MAIN_URL; ?>category/Adminlists/2" class="btn tooltipped col s4 offset-s4 l2 offset-l1" data-position="top" data-delay="50" data-tooltip="Event">Event</a>
                 
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col s12 m4 l3">
                <p class="header"></p>
              </div>
              <div class="col s12 m8 l9">
                  <p>Manage category by Performing <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="Add new category">Add</a>, <a class="tooltipped" data-position="bottom" data-delay="50" data-tooltip="Edit category">Edit</a>, <a class="tooltipped" data-position="left" data-delay="50" data-tooltip="Delete category permanantly">Delete</a> Operations.</p>
              </div>
            </div>

            <div class="row">
                <h4 class="header">Operations</h4>
             <p class="caption">
               
 You can add,edit and delete business,event categories and administrators ,it will be instantly updated into system.If having a long data for update than you can directly import excel sheet,it will automatically ignore repeated data and will update instantly from system
     
              </p>
              </div>
            </div>

        </div>