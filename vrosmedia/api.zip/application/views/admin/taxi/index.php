  <div class="container">
         

          <!--toasts-->
          <div id="toasts" class="section">
            
            <div class="row">
              <div class="col s12 m12 l12">
                
              </div>
              <div class="col s12 m12 l12">
                <div class="row" >
                
                  <div class="col s4 l2" style="margin-top: 10%;">
                        <a href="<?php echo ADMIN_MAIN_URL; ?>taxi/companylists/" class="btn tooltipped" data-position="bottom" data-delay="50" >Taxi Company </a>
                  </div>   
                
                     <div class="col s4 l2" style="margin-top: 10%;">
                        <a href="<?php echo ADMIN_MAIN_URL; ?>taxi/classlists/<?php echo $value['id']?>" class="btn tooltipped" data-position="bottom" data-delay="50" >Taxi Class </a>
                  </div>   
                
                          
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col s12 m4 l3">
                <p class="header"></p>
              </div>
            
            </div>

            <div class="row">
             
              </div>
            </div>
        </div>