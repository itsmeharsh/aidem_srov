  <div class="container">
         

          <!--toasts-->
          <div id="toasts" class="section">
            <h4 class="header">User Managements</h4>
            <div class="row">
              <div class="col s12 m4 l3">
                <p>You can select options from right side ,where you can manage whole users of VROS media Systems.</p>
              </div>
              <div class="col s12 m8 l9">
                <div class="row">
                  <a href="<?php echo ADMIN_MAIN_URL; ?>user/Adminlists/a" class="btn tooltipped col s4 l2 " data-position="bottom" data-delay="50" data-tooltip="Admin users">Admin </a>
                  <a href="<?php echo ADMIN_MAIN_URL; ?>user/Adminlists/u" class="btn tooltipped col s4 offset-s4 l2 offset-l1" data-position="top" data-delay="50" data-tooltip="Applications users"> Applications Users</a>
                  <a href="<?php echo ADMIN_MAIN_URL; ?>user/Adminlists/d" class="btn tooltipped col s4 offset-s4 l2 offset-l1" data-position="left" data-delay="50" data-tooltip="Drivers"> Drivers</a>
                 
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col s12 m4 l3">
                <p class="header"></p>
              </div>
              <div class="col s12 m8 l9">
                  <p>Manage users by Performing <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="Add new user">Add</a>, <a class="tooltipped" data-position="bottom" data-delay="50" data-tooltip="Edit user">Edit</a>, <a class="tooltipped" data-position="left" data-delay="50" data-tooltip="Delete user permanantly">Delete</a> Operations.</p>
              </div>
            </div>

            <div class="row">
                <h4 class="header">Operations</h4>
             <p class="caption">
               
 You can add,edit and delete drivers,application users and administrators ,it will be instantly updated into system.If having a long data for update than you can directly import excel sheet,it will automatically ignore repeated data and will update instantly from system
     
              </p>
              </div>
            </div>

        </div>