<?php

class User_model extends Common_model
{

   public $_table = TBL_USER;
    public $_fields = "*";
    public $_where = array();
    protected $_primary_key = 'id';
    public $_except_fields = array();

    function __construct()
    {
        parent::__construct();
        $this->load->helper('cookie');
    }

     function getUserData() {
         $this->db->select("IF(user_type = 'a' , 'Admin' , 'Driver'),'user_type'",false);         
        $this->db->select($this->_fields, FALSE);
        $this->db->from($this->_table);
        $this->db->where($this->_where);

        $query = $this->db->get();
       
        if ($query->num_rows() > 0)
            return $query->result();
        else
            return '';
    }
   function checkUserEmailAvailable($email, $iUserID = '')
    {
        if (isset($iUserID) && $iUserID != '')
            $ucheck = array('email' => $email, 'id <>' => $iUserID,'deleted' => '0');
        else
            $check = array('email' => $email,'deleted' => '0');

        $result = $this->db->get_where(TBL_USER, (isset($ucheck) && $ucheck != '') ? $ucheck : $check);
        
        if ($result->num_rows() >= 1)
            return 0;
        else
            return 1;
    }
    function getFormData($userType){
         if($userType=='u'){
             $moduleName='Applications User';
         }elseif($userType=='d'){
             $moduleName='Drivers';
         }else{
             $moduleName='Admin';
         }
         $where=array('vTitle'=>$moduleName,'eDelete'=>'0','eStatus'=>'Active');
         $this->db->from(TBL_FORMS);
         $this->db->where('vTitle', $moduleName);
         $this->db ->join(TBL_FORM_FIELDS,TBL_FORMS.'.iFormID='.TBL_FORM_FIELDS.'.iFromID');        
         $query = $this->db->get(); 
         if ($query->num_rows() > 0)
            return $query->result();
        else
            return '';
    }
     public function insertData($postData = array(), $key = '', $id = '') {

        if ($id == NULL) {            
            // Insert Here            
            $postArray = $this->general_model->getDatabseFields($postData, TBL_USER);
            $id=parent::insert($postData);           
            
        } else {
            
            // Update here
            $postArray = $this->general_model->getDatabseFields($postData, TBL_USER);
            parent::update($postData, $id);
            
        }
        return $id;
    }
    function update_user($data, $id = NULL) {                
		$this->_table_name =TBL_USER;
		parent::update($data, $id);
		return $id;
                
    }
    function getMyWishListsData($postData = array()) {                
		$this->_table_name =TBL_USER;
		parent::update($data, $id);
		return $id;
                
    }
     

}

?>