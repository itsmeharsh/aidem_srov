<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Graph_model_v1 extends MY_Model {



    function __construct() {
        parent::__construct();

    }
    function Graph($business_id,$type)
    {
        $query_data='';
        $start_date= '2015-12-25';
        $days=10;
        $query_data.='select '.$start_date.' as day';
        for($i=1;$i<=$days;$i++){
            $query_data.='union select '.$start_date.' - interval '.$i.' day ';
        }


        $result=$this->db->query('SELECT days.day, count(clicks) as clicks FROM
                    (   select DATE_ADD('.$start_date.', INTERVAL - 0 DAY) as day
                        union select DATE_ADD('.$start_date.', INTERVAL  - 1 DAY)
                        union select DATE_ADD('.$start_date.', INTERVAL  - 2 DAY)
                        union select DATE_ADD('.$start_date.', INTERVAL  - 3 DAY)
                        union select DATE_ADD('.$start_date.', INTERVAL  - 4 DAY)
                        union select DATE_ADD('.$start_date.', INTERVAL  - 5 DAY)
                      ) days
                left join  advertise_revenue
                 on days.day =  advertise_revenue.date
                 WHERE (advertise_revenue.business_id="'.$business_id.'" OR advertise_revenue.business_id IS NULL) AND  (advertise_revenue.type="'.$type.'"  OR advertise_revenue.business_id IS NULL) AND (advertise_revenue.deleted="0"  OR advertise_revenue.business_id IS NULL)
              group by
                days.day');


        return $result->result_array();
    }
    function tests($business_id,$type)
    {

        $start_date='2015-12-25';
        $result=$this->db->query('SELECT days.day, count(clicks) as clicks FROM
                    (   select '.$start_date.' as day
                        union select '.$start_date.' - interval 1 day
                        union select '.$start_date.' - interval 2 day
                        union select '.$start_date.' - interval 3 day
                        union select '.$start_date.' - interval 4 day
                        union select '.$start_date.' - interval 5 day
                        union select '.$start_date.' - interval 6 day
                        union select '.$start_date.' - interval 7 day
                        union select '.$start_date.' - interval 8 day
                        union select '.$start_date.' - interval 9 day
                        union select '.$start_date.' - interval 10 day
                        union select '.$start_date.' - interval 11 day
                        union select '.$start_date.' - interval 12 day
                        union select '.$start_date.' - interval 13 day
                        union select '.$start_date.' - interval 14 day
                        union select '.$start_date.' - interval 15 day
                        union select '.$start_date.' - interval 16 day
                        union select '.$start_date.' - interval 17 day
                        union select '.$start_date.' - interval 18 day
                        union select '.$start_date.' - interval 19 day
                        union select '.$start_date.' - interval 20 day
                        union select '.$start_date.' - interval 21 day
                        union select '.$start_date.' - interval 22 day
                        union select '.$start_date.' - interval 23 day
                        union select '.$start_date.' - interval 24 day
                        union select '.$start_date.' - interval 25 day
                        union select '.$start_date.' - interval 26 day
                        union select '.$start_date.' - interval 27 day
                        union select '.$start_date.' - interval 29 day
                        union select '.$start_date.' - interval 30 day
                      ) days
                left join  advertise_revenue
                 on days.day =  advertise_revenue.date
                 WHERE (advertise_revenue.business_id="'.$business_id.'" OR advertise_revenue.business_id IS NULL) AND  (advertise_revenue.type="'.$type.'"  OR advertise_revenue.business_id IS NULL) AND (advertise_revenue.deleted="0"  OR advertise_revenue.business_id IS NULL)
              group by
                days.day');


        return $result->result_array();
    }





}
