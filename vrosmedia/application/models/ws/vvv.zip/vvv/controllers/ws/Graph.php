<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Graph extends Ws_Controller {
    private $model;
    public function __construct() {
        parent::__construct();
        parent::load_version_model('ws/Graph_model_' . $this->data['version'], 'graph_model');
    }
    public function QRGraph()
    {
        $responseData = array();
        $this->form_validation->set_rules($this->Graph_rules());
        if ($this->form_validation->run() == FALSE) {

            $responseData['code'] = 400;
            $responseData['status'] = 'error';
            $responseData['message'] = $this->lang->language["err_req_values"];


        } else {
            $postArray = $this->input->post();
        
            $getData=$this->graph_model->Graph($postArray['business_id'],3);
            
            if(!empty($getData)){
                $responseData['code'] = 200;
                $responseData['status'] ='success';
                $responseData['data'] =$getData;
            }else{
                $responseData['code'] = 200;
                $responseData['status'] = 'success';
                $responseData['message']= $this->lang->language["NO_DATA_FOUND"];
            }

        }
        je_mobile($responseData);
    }
    public function  ImpressionGraph(){

        $responseData = array();
        $this->form_validation->set_rules($this->Graph_rules());
        if ($this->form_validation->run() == FALSE) {

            $responseData['code'] = 400;
            $responseData['status'] = 'error';
            $responseData['message'] = $this->lang->language["err_req_values"];


        } else {
            $postArray = $this->input->post();

            $getData=$this->graph_model->Graph($postArray['business_id'],2);

            if(!empty($getData)){
                $responseData['code'] = 200;
                $responseData['status'] ='success';
                $responseData['data'] =$getData;
            }else{
                $responseData['code'] = 200;
                $responseData['status'] = 'success';
                $responseData['message']= $this->lang->language["NO_DATA_FOUND"];
            }

        }
        je_mobile($responseData);

    }

    protected function Graph_rules() {
        $rules = array(
            array(
                'field' => 'business_id',
                'label' => 'business_id',
                'rules' => 'trim|required|xss_clean',
            ),
        );
        return $rules;
    }





}
