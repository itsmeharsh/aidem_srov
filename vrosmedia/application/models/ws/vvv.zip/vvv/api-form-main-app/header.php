<?php
if($_SERVER['SERVER_NAME']=="localhost")
$path = "http://localhost/demo/bs/index.php/ws/v1/";

else
$path = "http://imobcreator.com/android_apps/businessAppFinal/index.php/ws/v1/";

?>



