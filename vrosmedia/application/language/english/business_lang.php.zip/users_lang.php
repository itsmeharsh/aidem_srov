<?php
$lang['user_first_name'] = "First Name";
$lang['user_last_name'] = "Last Name";
$lang['user_email'] = "Email";
$lang['user_deviceToken'] = "DeviceID";
$lang['user_password'] = "Password";
$lang['user_facebook_id'] = "Facebook Id";
$lang['user_dob'] = "Birth Date";
$lang['user_gender'] = "Gender";
$lang['user_old_password'] = "Old password";
$lang['user_new_password'] = "New password";
$lang['social_type'] = "Social Type";
$lang['social_id'] = "Social ID";
$lang['userid'] = "userid";

$lang['LATTITUDE'] = "Latitude";
$lang['LONGITUDE'] = "Longitude";

$lang['NO_DATA_FOUND'] = "No Data Found";